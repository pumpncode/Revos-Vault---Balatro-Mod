
-------------MOD CODE-------------

--credits to astromunch for the example mod and youtube tutorials. Really helped me out

--SMODS.Rarity{
   -- key = 'printers', 
   -- loc_txt = { 
   --     name = 'Printers', 
   -- },
   -- badge_colour = '808080', 
   -- default_weight = 3 -- 
--}


function joker_add(jKey)

    if type(jKey) == 'string' then
        
        local j = SMODS.create_card({
            key = jKey,
        })

        j:add_to_deck()
        G.jokers:emplace(j)
        -- (Credit to @AstroLighz for the deck codes)
        SMODS.Stickers["eternal"]:apply(j, true)

    end
end

SMODS.Atlas{
    key = 'Decks', 
    path = 'Decks.png', 
    px = 71, 
    py = 95 
}


SMODS.Atlas{
    key = 'Jokers', 
    path = 'Jokers.png', 
    px = 71, 
    py = 95 
}

-------JOKERS------


SMODS.Joker{
    key = 'printer', 
    loc_txt = { 
        name = 'Blueprinter',
        text = {
          'When Blind is selected,',
          'create a {C:attention}Blueprint{} Joker',
        },
        
    },
    atlas = 'Jokers', 
    rarity = 4, 
    cost = 50, 
    unlocked = true, 
    discovered = true, 
    blueprint_compat = false,
    eternal_compat = true, 
    perishable_compat = false, 
    pos = {x = 0, y = 0},
    config = { 
      extra = {

      }
    },
    loc_vars = function(self,info_queue,center)
        info_queue[#info_queue+1] = G.P_CENTERS.j_blueprint
    end,

    calculate = function(self,card,context)
        if context.setting_blind then
            local new_card = create_card('Blueprint', G.jokers, nil,nil,nil,nil,'j_blueprint')
            new_card:add_to_deck()
            G.jokers:emplace(new_card)
        end
    end,
    in_pool = function(self,wawa,wawa2)
        return true
    end,
   }

   SMODS.Joker{
    key = 'rustyprinter', 
    loc_txt = { 
        name = 'Rusty Printer',
        text = {
          'When Blind is selected,',
          'create a {C:attention}Brainstorm{} Joker',
        },

    },
    atlas = 'Jokers', 
    rarity = 4, 
    cost = 50, 
    unlocked = true, 
    discovered = true, 
    blueprint_compat = false, 
    eternal_compat = true, 
    perishable_compat = false, 
    pos = {x = 1, y = 0}, 
    config = { 
      extra = {

      }
    },
    loc_vars = function(self,info_queue,center)
        info_queue[#info_queue+1] = G.P_CENTERS.j_brainstorm 
    end,
    calculate = function(self, card, context)
        if context.setting_blind then
            local new_card = create_card('Brainstorm', G.jokers, nil,nil,nil,nil,'j_brainstorm')
            new_card:add_to_deck()
            G.jokers:emplace(new_card)

        end
    end,
    in_pool = function(self,wawa,wawa2)
        
        return true
    end,
   }

   SMODS.Joker{
    key = 'jimboprinter', 
    loc_txt = { 
        name = 'Jimbo Printer',
        text = {
          'When Blind is selected,',
          'create a {C:dark_edition}Negative {}{C:attention}Joker {}',
        },
   
    },
        atlas = 'Jokers', 
        rarity = 4,
        cost = 50, 
        unlocked = true,
        discovered = true,
        blueprint_compat = false,
        eternal_compat = true,
        perishable_compat = false,
        pos = {x = 2, y = 0},
        config = { 
          extra = {

      }
    },
    loc_vars = function(self,info_queue,center)
    end,
    calculate = function(self,card,context)
        if context.setting_blind then
            local new_card = create_card('Joker', G.jokers, nil,nil,nil,nil,'j_joker')
            new_card:set_edition({negative = true}, true)
            new_card:add_to_deck()
            G.jokers:emplace(new_card)
        end
    end,
    in_pool = function(self,wawa,wawa2)
      
        return true
    end,
   }

   SMODS.Joker{
    key = 'grossprinter', 
    loc_txt = { 
        name = 'Gross Printer',
        text = {
          'When Blind is selected,',
          'create a {C:attention}Gros Michel{}',
        },

    },
    atlas = 'Jokers', 
    rarity = 4,
    
    cost = 50, 
    unlocked = true, 
    discovered = true, 
    blueprint_compat = false, 
    eternal_compat = true, 
    perishable_compat = false, 
    pos = {x = 0, y = 1},
    config = { 
      extra = {

      }
    },
    loc_vars = function(self,info_queue,center)
        info_queue[#info_queue+1] = G.P_CENTERS.j_gross_michel 
    end,
    calculate = function(self,card,context)

        if context.setting_blind then
            local new_card = create_card('Gros Michel', G.jokers, nil,nil,nil,nil,'j_gros_michel')
            new_card:add_to_deck()
            G.jokers:emplace(new_card)
        end
    end,
    in_pool = function(self,wawa,wawa2)
        
        return true
    end,
   }

   SMODS.Joker{
    key = 'obeliskprinter', 
    loc_txt = { 
        name = 'Obelisk Printer',
        text = {
          'When Blind is selected,',
          'create a {C:dark_edition}Negative{} {C:attention}Obelisk{} Joker',
        },
    },
    atlas = 'Jokers', 
    rarity = 4, 
 
    cost = 40, 
    unlocked = true, 
    discovered = true, 
    blueprint_compat = false,
    eternal_compat = true, 
    perishable_compat = false, 
    pos = {x = 1, y = 1}, 
    config = { 
      extra = {

      }
    },
    loc_vars = function(self,info_queue,center)
        info_queue[#info_queue+1] = G.P_CENTERS.j_obelisk
    end,
    calculate = function(self,card,context)
        if context.setting_blind then
            local new_card = create_card('Obelisk', G.jokers, nil,nil,nil,nil,'j_obelisk')
            new_card:set_edition({negative = true}, true)
            new_card:add_to_deck()
            G.jokers:emplace(new_card)
        end
    end,
    in_pool = function(self,wawa,wawa2)
        return true
    end,
   }

   SMODS.Joker{
    key = 'moneyprinter', 
    loc_txt = { 
        name = 'Money Printer',
        text = {
          'When Blind is selected,',
          'create a {C:dark_edition}Negative{} {C:attention}Obelisk{} Joker',
        },
    },
    atlas = 'Jokers', 
    rarity = 4, 
 
    cost = 50, 
    unlocked = true, 
    discovered = true, 
    blueprint_compat = false,
    eternal_compat = true, 
    perishable_compat = false, 
    pos = {x = 2, y = 1}, 
    config = { 
      extra = {
      }
    },
      
    in_pool = function(self,wawa,wawa2)
        return true
    end,

    calc_dollar_bonus = function(self,card)
        return 25
    end,
   }

    local card_keys = {
        'j_8_ball', 'j_abstract', 'j_acrobat', 'j_ancient', 'j_arrowhead', 'j_astronomer', 'j_banner', 'j_baron',
        'j_baseball', 'j_blackboard', 'j_bloodstone', 'j_blue_joker', 'j_blueprint', 'j_bootstraps', 'j_brainstorm',
        'j_bull', 'j_burglar', 'j_burnt', 'j_business', 'j_caino', 'j_campfire', 'j_card_sharp', 'j_cartomancer',
        'j_castle', 'j_cavendish', 'j_ceremonial', 'j_certificate', 'j_chaos', 'j_chicot', 'j_clever', 'j_cloud_9',
        'j_constellation', 'j_crafty', 'j_crazy', 'j_credit_card', 'j_delayed_grat', 'j_devious', 'j_diet_cola',
        'j_dna', 'j_drivers_license', 'j_droll', 'j_drunkard', 'j_duo', 'j_dusk', 'j_egg', 'j_erosion', 'j_even_steven',
        'j_faceless', 'j_family', 'j_fibonacci', 'j_flash', 'j_flower_pot', 'j_fortune_teller', 'j_four_fingers',
        'j_gift', 'j_glass', 'j_gluttenous_joker', 'j_golden', 'j_greedy_joker', 'j_green_joker', 'j_gros_michel',
        'j_hack', 'j_half', 'j_hallucination', 'j_hanging_chad', 'j_hiker', 'j_hit_the_road', 'j_hologram', 'j_ice_cream',
        'j_idol', 'j_invisible', 'j_joker', 'j_jolly', 'j_juggler', 'j_loyalty_card', 'j_luchador', 'j_lucky_cat',
        'j_lusty_joker', 'j_mad', 'j_madness', 'j_mail', 'j_marble', 'j_matador', 'j_merry_andy', 'j_midas_mask',
        'j_mime', 'j_misprint', 'j_mr_bones', 'j_mystic_summit', 'j_obelisk', 'j_odd_todd', 'j_onyx_agate', 'j_oops',
        'j_order', 'j_pareidolia', 'j_perkeo', 'j_photograph', 'j_popcorn', 'j_raised_fist', 'j_ramen', 'j_red_card',
        'j_reserved_parking', 'j_ride_the_bus', 'j_riff_raff', 'j_ring_master', 'j_rocket', 'j_rough_gem', 'j_runner',
        'j_satellite', 'j_scary_face', 'j_scholar', 'j_seance', 'j_seeing_double', 'j_selzer', 'j_shoot_the_moon',
        'j_shortcut', 'j_sixth_sense', 'j_sly', 'j_smeared', 'j_smiley', 'j_sock_and_buskin', 'j_space', 'j_splash',
        'j_square', 'j_steel_joker', 'j_stencil', 'j_stone', 'j_stuntman', 'j_supernova', 'j_superposition',
        'j_swashbuckler', 'j_throwback', 'j_ticket', 'j_to_the_moon', 'j_todo_list', 'j_trading', 'j_tribe', 'j_triboulet',
        'j_trio', 'j_troubadour', 'j_trousers', 'j_turtle_bean', 'j_vagabond', 'j_vampire', 'j_walkie_talkie', 'j_wee',
        'j_wily', 'j_wrathful_joker', 'j_yorick', 'j_zany'
    }
    
    SMODS.Joker{
        key = 'brokenprinter', -- joker key
        loc_txt = { -- local text
            name = 'Broken Printer',
            text = {
              'When Blind is selected,',
              'create a {C:attention}Random Joker{}',
            },
        },
        atlas = 'Jokers', 
        rarity = 4, 
        cost = 50, 
        unlocked = true, 
        discovered = true, 
        blueprint_compat = false,
        eternal_compat = true, 
        perishable_compat = false, 
        pos = {x = 0, y = 2}, 
        config = { 
          extra = {
          }
        },
        calculate = function(self, card, context)
            if context.setting_blind then
                local random_key = card_keys[math.random(#card_keys)]
                local new_card = create_card(random_key, G.jokers, nil, nil, nil, nil, random_key)
                new_card:add_to_deck()
                G.jokers:emplace(new_card)
            end
        end,
        in_pool = function(self, wawa, wawa2)
           
            return true
        end,
    }
    
    ----------------DECKS----------------
    SMODS.Back{
        name = 'Old Scroll',
        key = 'os',
        atlas = 'Decks',
        pos = {x = 1, y = 0},
        loc_txt = {
            name = 'Old Scroll',
            text = {
                'Start with an',
                'Eternal{C:attention} Rusty Printer{}.'
            },
        },
        apply = function ()
    
            G.E_MANAGER:add_event(Event({
    
                func = function ()
    
    
                    joker_add('j_crv_rustyprinter')
    
    
                    return true
                end
            }))
        end
    }
    
    SMODS.Back{
        name = 'Machinery',
        key = 'mach',
        atlas = 'Decks',
        pos = {x = 0, y = 0},
        loc_txt = {
            name = 'Machinery',
            text = {
                'Start with an',
                'Eternal {C:attention}Blueprinter{}'
            },
        },
        apply = function ()
    
            G.E_MANAGER:add_event(Event({
    
                func = function ()
    
    
                    joker_add('j_crv_printer')
    
    
                    return true
                end
            }))
        end
    }
    
    SMODS.Back{
        name = 'Gold Mayhem',
        key = 'gm',
        atlas = 'Decks',
        pos = {x = 2, y = 1},
        loc_txt = {
            name = 'Gold Mayhem',
            text = {
                'Start with an',
                'Eternal {C:money}Money Printer{}',
            },
        },
        apply = function ()
    
            G.E_MANAGER:add_event(Event({
    
                func = function ()
    
    
                    joker_add('j_crv_moneyprinter')
    
    
                    return true
                end
            }))
        end
    }
    
    
        SMODS.Back{
        name = 'Ripped Deck',
        key = 'rpd',
        atlas = 'Decks',
        pos = {x = 0, y = 2},
        loc_txt = {
            name = 'Ripped Deck',
            text = {
                'Start with an',
                'Eternal {C:attention}Broken Printer{}',
            },
        },
        apply = function ()
    
            G.E_MANAGER:add_event(Event({
    
                func = function ()
    
    
                    joker_add('j_crv_brokenprinter')
    
    
                    return true
                end
            }))
        end
    }
    
    SMODS.Back{
        name = 'Jimbo World',
        key = 'jw',
        atlas = 'Decks',
        pos = {x = 2, y = 0},
        loc_txt = {
            name = 'Jimbo World',
            text = {
                'Start with an',
                'Eternal {C:attention}Jimbo Printer{}',
            },
        },
        apply = function ()
    
            G.E_MANAGER:add_event(Event({
    
                func = function ()
    
    
                    joker_add('j_crv_jimboprinter')
    
    
                    return true
                end
            }))
        end
    }
    
    SMODS.Back{
        name = 'Gross Deck',
        key = 'gd',
        atlas = 'Decks',
        pos = {x = 0, y = 1},
        loc_txt = {
            name = 'Gross Deck',
            text = {
                'Start with an',
                'Eternal {C:attention}Gross Printer{}',
            },
        },
        apply = function ()
    
            G.E_MANAGER:add_event(Event({
    
                func = function ()
    
    
                    joker_add('j_crv_grossprinter')
    
    
                    return true
                end
            }))
        end
    }
    
    SMODS.Back{
        name = 'The Suspicious Desert',
        key = 'tsd',
        atlas = 'Decks',
        pos = {x = 1, y = 1},
        loc_txt = {
            name = 'The Suspicious Desert',
            text = {
                'Start with an',
                'Eternal {C:attention}Obelisk Printer{}',
            },
        },
        apply = function ()
    
            G.E_MANAGER:add_event(Event({
    
                func = function ()
    
    
                    joker_add('j_crv_obeliskprinter')
    
    
                    return true
                end
            }))
        end
    }
    