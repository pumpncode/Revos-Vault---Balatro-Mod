
-------------MOD CODE-------------





--credits to astromunch for the example mod and youtube tutorials. Really helped me out




--atlas--
SMODS.Atlas{
    key = 'wip', 
    path = 'wip.png', 
    px = 71, 
    py = 95 
}


SMODS.Atlas{
    key = 'Decks', 
    path = 'Decks.png', 
    px = 71, 
    py = 95 
}


SMODS.Atlas{
    key = 'Jokers', 
    path = 'Jokers.png', 
    px = 71, 
    py = 95 
}

SMODS.Atlas{
    key = 'tarots', 
    path = 'tarots.png', 
    px = 71, 
    py = 95 
}

SMODS.Atlas{
    key = 'documents', 
    path = 'documents.png', 
    px = 71, 
    py = 95 
}

SMODS.Atlas{
    key = 'documents_u', 
    path = 'documents2.png',
    px = 71,
    py = 95 
}

SMODS.Atlas{
    key = 'enh', 
    path = 'enh.png',
    px = 71,
    py = 95 
}





---------------ENHANCEMENTS-----------------
SMODS.Enhancement{
    key = "bulletproofglass",
    atlas = 'enh',
    pos = {x = 0, y = 0},
    discovered = false,
    unlocked = true,
    loc_txt = { 
        name = 'Bulletproof Glass',
        text = {
            '{X:mult,C:white}X#1#{} Mult',
            '{C:green}#2# in #3# {}chance to',
            'destroy the card',
        }},
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    overrides_base_rank = false,
    any_suit = false,
    always_scores = false,
    weight = 0,
    config = {extra = {x_mult = 4, odds = 6}
    },
    loc_vars = function(self, info_queue, card)
        return { vars = {card.ability.extra.x_mult,(G.GAME.probabilities.normal or 1), card.ability.extra.odds} }
      end,
      calculate = function(self, card, context, effect)
        if context.cardarea == G.play and not context.repetition then
            effect.x_mult = card.ability.extra.x_mult
            if pseudorandom('bulletproofglass') < G.GAME.probabilities.normal / card.ability.extra.odds then
                G.E_MANAGER:add_event(Event({
                    func = function()
                      card.T.r = -0.2
                      card:juice_up(0.3, 0.4)
                      card.states.drag.is = true
                      card.children.center.pinch.x = true
                      -- This part destroys the card.
                      G.E_MANAGER:add_event(Event({
                        func = function()
                          G.jokers:remove_card(card)
                          card:remove()
                          card = nil
                          return true;
                        end
                      }))
                      return true
                    end
                  }))
        end
    end
end,
}




---------------CONSUMEABLES-----------------


local printer_keys = {'j_crv_printer','j_crv_rustyprinter','j_crv_jimboprinter','j_crv_grossprinter','j_crv_obeliskprinter','j_crv_moneyprinter','j_crv_brokenprinter','j_crv_faxprinter','j_crv_spectralprinter',
'j_crv_glassprinter'}

SMODS.Consumable{
    key = 'ink&intuition', 
    set = 'Tarot',
    loc_txt = { 
        name = 'Ink & Intuition',
        text = {
            '{C:green}#1# in #2#{} chance to',
            'create a {C:attention}Printer',
            '{C:inactive}(Must have room)',
        },
    },
    config = { extra = { odds = 3 }},
    loc_vars = function(self, info_queue, card)
        return { vars = { (G.GAME.probabilities.normal or 1), card.ability.extra.odds } }
      end, 
    pos = { x = 0, y = 0 },
    atlas = 'tarots',
    cost = 3,
    unlocked = true,
    discovered = true,
    can_use = function(self,card)
        if #G.jokers.cards < G.jokers.config.card_limit or self.area == G.jokers then
        return true
        end
    end,
    use = function(self,card)
        if pseudorandom('ink&intuition') < G.GAME.probabilities.normal / card.ability.extra.odds then   
            local random_key = printer_keys[math.random(#printer_keys)]
                local new_card = create_card(random_key, G.jokers, nil, nil, nil, nil, random_key)
                new_card:add_to_deck()
                G.jokers:emplace(new_card)
        else
            G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.4, func = function()
                    G.E_MANAGER:add_event(Event({trigger = 'after', delay = 0.06*G.SETTINGS.GAMESPEED, blockable = false, blocking = false, func = function()
                        play_sound('tarot2', 0.76, 0.4);return true end}))
                        play_sound('tarot2', 1, 0.4)
                        card.juice_up(0.3, 0.5)
            return true end }))
        end
        delay(1.5)
    end
        }
 

        SMODS.ConsumableType{
            key = 'EnchancedDocuments', --consumable type key
        
            collection_rows = {4,5}, --amount of cards in one page
            primary_colour = G.C.PURPLE, --first color
            secondary_colour = G.C.DARK_EDITION, --second color
            loc_txt = {
                collection = 'Documents', --name displayed in collection
                name = 'Glass Document', --name displayed in badge
                undiscovered = {
                    name = '???', --undiscovered name
                    text = {'???'} --undiscovered text
                }
            },
            shop_rate = 0, --rate in shop out of 100
        }
    
        SMODS.UndiscoveredSprite{
            key = 'EnchancedDocuments', --must be the same key as the consumabletype
            atlas = 'documents_u',
            pos = {x = 0, y = 0}
        }
        
    
    
        SMODS.Consumable{
            key = 'glassdocument', --key
            set = 'EnchancedDocuments', --the set of the card: corresponds to a consumable type
            atlas = 'documents', --atlas
            pos = {x = 0, y = 0}, --position in atlas
            loc_txt = {
                name = 'Glass Document', --name of card
                text = { --text of card
                    'Turns #1# card into {C:attention}Glass',
                    '{C:green} #2# in #3#{} chane for it to be a',
                    '{C:dark_edition} Bulletproof Glass{}'
                }
            },
            config = {
                extra = {
                    cards = 1, odds = 4}
            },
            loc_vars = function(self, info_queue, card)
                return { vars = { card.ability.extra.cards, (G.GAME.probabilities.normal or 1), card.ability.extra.odds } }
              end,
            can_use = function(self,card)
                if G and G.hand then
                    if #G.hand.highlighted ~= 0 and #G.hand.highlighted <= card.ability.extra.cards then --if cards in hand highlighted are above 0 but below the configurable value then
                        return true
                    end
                end
                return false
            end,
            use = function(self,card,area,copier)
                if pseudorandom('glassdocument') < G.GAME.probabilities.normal / card.ability.extra.odds then
                    for i, card in pairs(G.hand.highlighted) do
                        card:set_ability(G.P_CENTERS["m_crv_bulletproofglass"])
                    end
            else 
                for i, card in pairs(G.hand.highlighted) do
                    card:set_ability(G.P_CENTERS["m_glass"])
            end
             end
            end,
        }
        
    



---------------JOKERS-----------------

function joker_add(jKey)

    if type(jKey) == 'string' then
        
        local j = SMODS.create_card({
            key = jKey,
        })

        j:add_to_deck()
        G.jokers:emplace(j)
        -- (Credit to @AstroLighz for the deck codes)
        SMODS.Stickers["eternal"]:apply(j, true)


    end
end

function joker_add_etx(jKey)

    if type(jKey) == 'string' then
        
        local j = SMODS.create_card({
            key = jKey,
        })

        j:add_to_deck()
        G.jokers:emplace(j)

    end
end

function joker_add_per(jKey)

    if type(jKey) == 'string' then
        
        local j = SMODS.create_card({
            key = jKey,
        })

        j:add_to_deck()
        G.jokers:emplace(j)
        SMODS.Stickers["perishable"]:apply(j, true)

    end
end



-------JOKERS------


SMODS.Joker{
    key = 'printer', 
    loc_txt = { 
        name = 'Blueprinter',
        text = {
          'When Blind is selected,',
          'create a {C:attention}Blueprint{} Joker',
        },
        
    },
    atlas = 'Jokers', 
    rarity = 3, 
    cost = 30, 
    unlocked = true, 
    discovered = true, 
    blueprint_compat = false,
    eternal_compat = true, 
    perishable_compat = false, 
    pos = {x = 0, y = 0},
    config = { 
      extra = {

      }
    },

    calculate = function(self,card,context)
        if context.setting_blind then
            local new_card = create_card('Blueprint', G.jokers, nil,nil,nil,nil,'j_blueprint')
            new_card:add_to_deck()
            G.jokers:emplace(new_card)
        end
    end,
    in_pool = function(self,wawa,wawa2)
        return false
    end,
   }

   SMODS.Joker{
    key = 'rustyprinter', 
    loc_txt = { 
        name = 'Rusty Printer',
        text = {
          'When Blind is selected,',
          'create a {C:attention}Brainstorm{} Joker',
        },

    },
    atlas = 'Jokers', 
    rarity = 3, 
    cost = 30, 
    unlocked = true, 
    discovered = true, 
    blueprint_compat = false, 
    eternal_compat = true, 
    perishable_compat = false, 
    pos = {x = 1, y = 0}, 
    config = { 
      extra = {

      }
    },
    calculate = function(self, card, context)
        if context.setting_blind then
            local new_card = create_card('Brainstorm', G.jokers, nil,nil,nil,nil,'j_brainstorm')
            new_card:add_to_deck()
            G.jokers:emplace(new_card)

            end
        end,

    in_pool = function(self,wawa,wawa2)
        
        return false
    end,
   }

   SMODS.Joker{
    key = 'jimboprinter', 
    loc_txt = { 
        name = 'Jimbo Printer',
        text = {
          'When Blind is selected,',
          'create a {C:dark_edition}Negative {}{C:attention}Joker {}',
        },
   
    },
        atlas = 'Jokers', 
        rarity = 3,
        cost = 30, 
        unlocked = true,
        discovered = true,
        blueprint_compat = false,
        eternal_compat = true,
        perishable_compat = false,
        pos = {x = 2, y = 0},
        config = { 
          extra = {

      }
    },
    loc_vars = function(self,info_queue,center)
    end,
    calculate = function(self,card,context)
        if context.setting_blind then
            local new_card = create_card('Joker', G.jokers, nil,nil,nil,nil,'j_joker')
            new_card:set_edition({negative = true}, true)
            new_card:add_to_deck()
            G.jokers:emplace(new_card)
        end
    end,

    in_pool = function(self,wawa,wawa2)
      
        return false
    end,
   }

   SMODS.Joker{
    key = 'grossprinter', 
    loc_txt = { 
        name = 'Gross Printer',
        text = {
          'When Blind is selected,',
          'create a {C:attention}Gros Michel{}',
        
        },

    },
    atlas = 'Jokers', 
    rarity = 3,
    
    cost = 30, 
    unlocked = true, 
    discovered = true, 
    blueprint_compat = true, 
    eternal_compat = true, 
    perishable_compat = false, 
    pos = {x = 0, y = 1},
    config = { 
      extra = {

      }
    },

    calculate = function(self,card,context)

        if context.setting_blind then
            local new_card = create_card('Gros Michel', G.jokers, nil,nil,nil,nil,'j_gros_michel')
            new_card:add_to_deck()
            G.jokers:emplace(new_card)
        end
    end,
    in_pool = function(self,wawa,wawa2)
        
        return false
    end,
   }

   SMODS.Joker{
    key = 'obeliskprinter', 
    loc_txt = { 
        name = 'Obelisk Printer',
        text = {
          'When Blind is selected,',
          'create a {C:dark_edition}Negative{} {C:attention}Obelisk{} Joker',
        },
    },
    atlas = 'Jokers', 
    rarity = 3, 
 
    cost = 20, 
    unlocked = true, 
    discovered = true, 
    blueprint_compat = false,
    eternal_compat = true, 
    perishable_compat = false, 
    pos = {x = 1, y = 1}, 
    config = { 
      extra = {

      }
    },
    calculate = function(self, card, context)
        if context.setting_blind then
            local new_card = create_card('Obelisk', G.jokers, nil,nil,nil,nil,'j_obelisk')
            new_card:set_edition({negative = true}, true)
            new_card:add_to_deck()
            G.jokers:emplace(new_card)
        end
    end,
    in_pool = function(self, wawa, wawa2)
        return false
    end,
   }

   SMODS.Joker{
    key = 'moneyprinter', 
    loc_txt = { 
        name = 'Money Printer',
        text = {
          'When round ends,',
          'Gain {C:money}+$25{}',
        },
    },
    atlas = 'Jokers', 
    rarity = 3, 
 
    cost = 40, 
    unlocked = true, 
    discovered = true, 
    blueprint_compat = false,
    eternal_compat = true, 
    perishable_compat = false, 
    pos = {x = 2, y = 1}, 
    config = { 
      extra = {
      }
    },
      
    in_pool = function(self,wawa,wawa2)
        return false
    end,

    calc_dollar_bonus = function(self,card)
        return 25
    end,
   }

    local card_keys = {
        'j_8_ball', 'j_abstract', 'j_acrobat', 'j_ancient', 'j_arrowhead', 'j_astronomer', 'j_banner', 'j_baron',
        'j_baseball', 'j_blackboard', 'j_bloodstone', 'j_blue_joker', 'j_blueprint', 'j_bootstraps', 'j_brainstorm',
        'j_bull', 'j_burglar', 'j_burnt', 'j_business', 'j_caino', 'j_campfire', 'j_card_sharp', 'j_cartomancer',
        'j_castle', 'j_cavendish', 'j_ceremonial', 'j_certificate', 'j_chaos', 'j_chicot', 'j_clever', 'j_cloud_9',
        'j_constellation', 'j_crafty', 'j_crazy', 'j_credit_card', 'j_delayed_grat', 'j_devious', 'j_diet_cola',
        'j_dna', 'j_drivers_license', 'j_droll', 'j_drunkard', 'j_duo', 'j_dusk', 'j_egg', 'j_erosion', 'j_even_steven',
        'j_faceless', 'j_family', 'j_fibonacci', 'j_flash', 'j_flower_pot', 'j_fortune_teller', 'j_four_fingers',
        'j_gift', 'j_glass', 'j_gluttenous_joker', 'j_golden', 'j_greedy_joker', 'j_green_joker', 'j_gros_michel',
        'j_hack', 'j_half', 'j_hallucination', 'j_hanging_chad', 'j_hiker', 'j_hit_the_road', 'j_hologram', 'j_ice_cream',
        'j_idol', 'j_invisible', 'j_joker', 'j_jolly', 'j_juggler', 'j_loyalty_card', 'j_luchador', 'j_lucky_cat',
        'j_lusty_joker', 'j_mad', 'j_madness', 'j_mail', 'j_marble', 'j_matador', 'j_merry_andy', 'j_midas_mask',
        'j_mime', 'j_misprint', 'j_mr_bones', 'j_mystic_summit', 'j_obelisk', 'j_odd_todd', 'j_onyx_agate', 'j_oops',
        'j_order', 'j_pareidolia', 'j_perkeo', 'j_photograph', 'j_popcorn', 'j_raised_fist', 'j_ramen', 'j_red_card',
        'j_reserved_parking', 'j_ride_the_bus', 'j_riff_raff', 'j_ring_master', 'j_rocket', 'j_rough_gem', 'j_runner',
        'j_satellite', 'j_scary_face', 'j_scholar', 'j_seance', 'j_seeing_double', 'j_selzer', 'j_shoot_the_moon',
        'j_shortcut', 'j_sixth_sense', 'j_sly', 'j_smeared', 'j_smiley', 'j_sock_and_buskin', 'j_space', 'j_splash',
        'j_square', 'j_steel_joker', 'j_stencil', 'j_stone', 'j_stuntman', 'j_supernova', 'j_superposition',
        'j_swashbuckler', 'j_throwback', 'j_ticket', 'j_to_the_moon', 'j_todo_list', 'j_trading', 'j_tribe', 'j_triboulet',
        'j_trio', 'j_troubadour', 'j_trousers', 'j_turtle_bean', 'j_vagabond', 'j_vampire', 'j_walkie_talkie', 'j_wee',
        'j_wily', 'j_wrathful_joker', 'j_yorick', 'j_zany'
    }
    
    SMODS.Joker{
        key = 'brokenprinter', -- joker key
        loc_txt = { -- local text
            name = 'Broken Printer',
            text = {
              'When Blind is selected,',
              'create a {C:attention}Random Joker{}',

            },
        },
        atlas = 'Jokers', 
        rarity = 3, 
        cost = 30, 
        unlocked = true, 
        discovered = true, 
        blueprint_compat = true,
        eternal_compat = true, 
        perishable_compat = false, 
        pos = {x = 0, y = 2}, 
        config = { 
          extra = {
          }
        },
        calculate = function(self, card, context)
            if context.setting_blind then
                local random_key = card_keys[math.random(#card_keys)]
                local new_card = create_card(random_key, G.jokers, nil, nil, nil, nil, random_key)
                new_card:add_to_deck()
                G.jokers:emplace(new_card)
             end
            end,

        in_pool = function(self, wawa, wawa2)
           
            return false
        end,
    }

    SMODS.Joker {
        key = 'faxprinter',
        loc_txt = {
          name = 'Fax Printer',
          text = {
            'When blind is selected,',
            "{C:green}#1# in #2#{} chance this",
            "card prints a",
            "{C:attention} Document",
          }
        },
        config = { extra = { odds = 4 } },
        rarity = 3,
        atlas = 'Jokers',
        blueprint_compat = true,
        pos = { x = 1, y = 2 },
        cost = 30,
        eternal_compat = true,
        loc_vars = function(self, info_queue, card)
          return { vars = { (G.GAME.probabilities.normal or 1), card.ability.extra.odds } }
        end,
        calculate = function(self, card, context)
          if context.setting_blind then
            -- Another pseudorandom thing, randomly generates a decimal between 0 and 1, so effectively a random percentage.
            if pseudorandom('faxprinter') < G.GAME.probabilities.normal / card.ability.extra.odds then
                local new_card = create_card('Paper Work', G.jokers, nil,nil,nil,nil,'j_crv_document')
                new_card:add_to_deck()
                G.jokers:emplace(new_card)
            end
        end
    end,


        in_pool = function(self, wawa, wawa2)
           
            return false
        end

    }
    
    SMODS.Joker {
        key = 'pprwork',
        loc_txt = {
          name = 'Paperwork',
          text = {
            "Anything between {C:attention}9{} and {C:attention}2",
            "gives {C:chips}+#1#{} Chips and",
            "{C:mult}+#2#{} Mult when scored",
            '{C:inactive}(9 and 2 included){}',
          }
        },
        config = { extra = { chips = 20.4, mult = 9.8 } },
        rarity = 2,
        atlas = 'Jokers',
        blueprint_compat = true,
        discovered = true,
        pos = { x = 2, y = 2 },
        cost = 6,
        loc_vars = function(self, info_queue, card)
          return { vars = { card.ability.extra.chips, card.ability.extra.mult } }
        end,
        calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play then
            if context.other_card:get_id() >= 2 and context.other_card:get_id() <= 9 then
              return {
                chips = card.ability.extra.chips,
                mult = card.ability.extra.mult,
                card = card.other_card
              }
            end
        end
    end,

              in_pool = function(self, wawa, wawa2)
                return false
            end
      }

      local spectral_keys = {'c_ankh', 'c_aura', 'c_black_hole', 'c_cryptid', 'c_deja_vu', 'c_ectoplasm', 'c_familiar', 'c_grim', 'c_hex', 'c_immolate', 'c_incantation', 'c_medium', 'c_ouija', 'c_sigil', 'c_soul', 'c_talisman', 'c_trance', 'c_wraith'
}

      SMODS.Joker{
        key = 'spectralprinter', -- joker key
        loc_txt = { -- local text
            name = 'Spectral Printer',
            text = {
              'When Blind is selected,',
              'create a Random',
              '{C:dark_edition} Negative {C:attention}Spectral{}',
              '{C:attention}Card{}',
            },
        },
        atlas = 'Jokers', 
        rarity = 3, 
        cost = 30, 
        unlocked = true, 
        discovered = true, 
        blueprint_compat = false,
        eternal_compat = true, 
        perishable_compat = false, 
        pos = {x = 0, y = 3}, 
        config = { 
          extra = {
          }
        },
        calculate = function(self, card, context)
            if context.setting_blind then
                local random_key = spectral_keys[math.random(#spectral_keys)]
                local new_card = create_card(random_key, G.consumeables, nil, nil, nil, nil, random_key)
                new_card:set_edition({negative = true}, true)
                new_card:add_to_deck()
                G.consumeables:emplace(new_card)
             end
        end,
        in_pool = function(self, wawa, wawa2)
           
            return false
        end,
      }

      local leg_keys = {'j_caino','j_triboulet','j_yorick','j_chicot','j_perkeo'}

      SMODS.Joker{
        key = 'legendaryprinter', 
        loc_txt = { 
            name = 'Legendary Printer',
            text = {
              "{C:green}#1# in #2#{} chance this",
              "card prints a random {C:dark_edition}Temporary",
              "{C:dark_edition}Negative{C:attention} Legendary Joker"
            },
            
        },
        atlas = 'Jokers', 
        rarity = 4, 
        cost = 35, 
        unlocked = true, 
        discovered = true, 
        blueprint_compat = false,
        eternal_compat = true, 
        perishable_compat = false, 
        pos = {x = 1, y = 3},
        config = { 
          extra = { odds = 3 }
          },
          loc_vars = function(self, info_queue, card)
            return { vars = { (G.GAME.probabilities.normal or 1), card.ability.extra.odds } }
          end, 
        calculate = function(self, card, context)
            if context.setting_blind then
              -- Another pseudorandom thing, randomly generates a decimal between 0 and 1, so effectively a random percentage.
              if pseudorandom('legendaryprinter') < G.GAME.probabilities.normal / card.ability.extra.odds then
                local random_key = leg_keys[math.random(#leg_keys)]
                local new_card = create_card(random_key, G.jokers, nil, nil, nil, nil, random_key)
                new_card:set_edition({negative = true}, true)
                new_card:add_to_deck()
                G.jokers:emplace(new_card)
                SMODS.Stickers['perishable']:apply(new_card, true)
              end
          end
          in_pool = function(self, wawa, wawa2)
           
            return false
        end
      end
       
    }

    SMODS.Joker{
        key = 'glassprinter', 
        loc_txt = { 
            name = 'Glass Printer',
            text = {
                'Prints {C:attention}Glass Document{}',
                'When blind is selected,',
                "{C:green}#1# in #2#{} chance this",
                "card gets destroyed",
              }
        },
        atlas = 'Jokers', 
        rarity = 3, 
        cost = 30, 
        unlocked = true, 
        discovered = true, 
        blueprint_compat = false,
        eternal_compat = true, 
        perishable_compat = false, 
        pos = {x = 2, y = 3},
        config = { extra = { odds = 6 }, }, 
          loc_vars = function(self, info_queue, card)
            return { vars = { (G.GAME.probabilities.normal or 1), card.ability.extra.odds} }
          end,
        calculate = function(self,card,context)
            if context.setting_blind then
                if pseudorandom('glassprinter') < G.GAME.probabilities.normal / card.ability.extra.odds then
                    local new_card = create_card('Glass Document', G.consumeables, nil,nil,nil,nil,'c_crv_glassdocument')
                    new_card:add_to_deck()
                    G.consumeables:emplace(new_card) 
                    G.E_MANAGER:add_event(Event({
                        func = function()
                          card.T.r = -0.2
                          card:juice_up(0.3, 0.4)
                          card.states.drag.is = true
                          card.children.center.pinch.x = true
                          -- This part destroys the card.
                          G.E_MANAGER:add_event(Event({
                            func = function()
                              G.jokers:remove_card(card)
                              card:remove()
                              card = nil
                              return true;
                            end
                          }))
                          return true
                        end
                      }))
                                else
                                    local new_card = create_card('Glass Document', G.consumeables, nil,nil,nil,nil,'c_crv_glassdocument')
                                    new_card:add_to_deck()
                                    G.consumeables:emplace(new_card)                   
                                end
                            end
                        end,
                
        in_pool = function(self,wawa,wawa2)
            return false
        end
    }
    
    
            
    ----------------DECKS----------------
    SMODS.Back{
        name = 'Old Scroll',
        key = 'os',
        atlas = 'Decks',
        pos = {x = 1, y = 0},
        loc_txt = {
            name = 'Old Scroll',
            text = {
                'Start with an',
                'Eternal{C:attention} Rusty Printer{}.'
            },
        },
        apply = function ()
    
            G.E_MANAGER:add_event(Event({
    
                func = function ()
    
    
                    joker_add('j_crv_rustyprinter')
    
    
                    return true
                end
            }))
        end
    }
    
    SMODS.Back{
        name = 'Machinery',
        key = 'mach',
        atlas = 'Decks',
        pos = {x = 0, y = 0},
        loc_txt = {
            name = 'Machinery',
            text = {
                'Start with an',
                'Eternal {C:attention}Blueprinter{}'
            },
        },
        apply = function ()
    
            G.E_MANAGER:add_event(Event({
    
                func = function ()
    
    
                    joker_add('j_crv_printer')
    
    
                    return true
                end
            }))
        end
    }
    
    SMODS.Back{
        name = 'Gold Mayhem',
        key = 'gm',
        atlas = 'Decks',
        pos = {x = 2, y = 1},
        loc_txt = {
            name = 'Gold Mayhem',
            text = {
                'Start with an',
                'Eternal {C:money}Money Printer{}',
            },
        },
        apply = function ()
    
            G.E_MANAGER:add_event(Event({
    
                func = function ()
    
    
                    joker_add('j_crv_moneyprinter')
    
    
                    return true
                end
            }))
        end
    }
    
    
        SMODS.Back{
        name = 'Ripped Deck',
        key = 'rpd',
        atlas = 'Decks',
        pos = {x = 0, y = 2},
        loc_txt = {
            name = 'Ripped Deck',
            text = {
                'Start with an',
                'Eternal {C:attention}Broken Printer{}',
            },
        },
        apply = function ()
    
            G.E_MANAGER:add_event(Event({
    
                func = function ()
    
    
                    joker_add('j_crv_brokenprinter')
    
    
                    return true
                end
            }))
        end
    }
    
    SMODS.Back{
        name = 'Jimbo World',
        key = 'jw',
        atlas = 'Decks',
        pos = {x = 2, y = 0},
        loc_txt = {
            name = 'Jimbo World',
            text = {
                'Start with an',
                'Eternal {C:attention}Jimbo Printer{}',
            },
        },
        apply = function ()
    
            G.E_MANAGER:add_event(Event({
    
                func = function ()
    
    
                    joker_add('j_crv_jimboprinter')
    
    
                    return true
                end
            }))
        end
    }
    
    SMODS.Back{
        name = 'Gross Deck',
        key = 'gd',
        atlas = 'Decks',
        pos = {x = 0, y = 1},
        loc_txt = {
            name = 'Gross Deck',
            text = {
                'Start with an',
                'Eternal {C:attention}Gross Printer{}',
            },
        },
        apply = function ()
    
            G.E_MANAGER:add_event(Event({
    
                func = function ()
    
    
                    joker_add('j_crv_grossprinter')
    
    
                    return true
                end
            }))
        end
    }
    
    SMODS.Back{
        name = 'The Suspicious Desert',
        key = 'tsd',
        atlas = 'Decks',
        pos = {x = 1, y = 1},
        loc_txt = {
            name = 'The Suspicious Desert',
            text = {
                'Start with an',
                'Eternal {C:attention}Obelisk Printer{}',
            },
        },
        apply = function ()
    
            G.E_MANAGER:add_event(Event({
                func = function ()
                    joker_add('j_crv_obeliskprinter')
                    return true
                end
            }))
        end
    }

    SMODS.Back{
        name = 'Speaking Fax',
        key = 'spx',
        atlas = 'Decks',
        pos = {x = 1, y = 2},
        loc_txt = {
            name = 'Speaking Fax',
            text = {
                'Start with an',
                'Eternal {C:attention}Fax Printer{}',
            },
        },
        apply = function ()
    
            G.E_MANAGER:add_event(Event({
                func = function ()
                    joker_add('j_crv_faxprinter')
                    return true
                end
            }))
        end
    }

    SMODS.Back{
        name = 'Phantom Forge',
        key = 'phf',
        atlas = 'Decks',
        pos = {x = 2, y = 2},
        loc_txt = {
            name = 'Phantom Forge',
            text = {
                'Start with an',
                'Eternal {C:attention}Spectral Printer{}',
            },
        },
        apply = function ()
    
            G.E_MANAGER:add_event(Event({
                func = function ()
                    joker_add('j_crv_spectralprinter')
                    return true
                end
            }))
        end
    }
    
    SMODS.Back{
        name = 'Hollow Gems',
        key = 'hg',
        atlas = 'Decks',
        pos = {x = 0, y = 3},
        loc_txt = {
            name = 'Hollow Gems',
            text = {
                'Start with an',
                'Eternal{C:attention} Legendary Printer{}.'
            },
        },
        apply = function ()
    
            G.E_MANAGER:add_event(Event({
    
                func = function ()
    
    
                    joker_add('j_crv_legendaryprinter')
    
    
                    return true
                end
            }))
        end
    }

    SMODS.Back{
        name = 'Glassbound',
        key = 'gb',
        atlas = 'Decks',
        pos = {x = 1, y = 3},
        loc_txt = {
            name = 'Glassbound',
            text = {
                'Start with an',
                'Eternal{C:attention} Glass Printer{}.'
            },
        },
        apply = function ()
    
            G.E_MANAGER:add_event(Event({
    
                func = function ()
    
    
                    joker_add('j_crv_glassprinter')
    
    
                    return true
                end
            }))
        end
    }

    ---WIP---
    
    





























































































































    --- deep wip--- (i hate these bro ;-;)
--SMODS.Rarity{
--    key = 'wip', 
--    loc_txt = { 
--        name = 'Wip', 
--    },
--    badge_colour = '808080',
--    pools = {
--        ["Joker"] = true,
--    },
--}

    
    --SMODS.Joker{
   --     key = 'rarityjoker', 
   --     loc_txt = { 
   --         name = 'Rarity Test',
   --         text = {
   --           'When Blind is selected,',
   --           'create a {C:attention}Blueprint{} Joker',
   --         },
   --         
   --     },
   --     atlas = 'crv_wip', 
   --     rarity = 'wip', 
   --     cost = 1, 
   --     unlocked = true, 
   --     discovered = true, 
    --    blueprint_compat = false,
   --     eternal_compat = true, 
   --     perishable_compat = false, 
   --     pos = {x = 0, y = 0},
   --     config = { 
   --       extra = {
   --       }
   --     },
   --     calculate = function(self,card,context)
   --         if context.setting_blind then
   --             local new_card = create_card('Wip', G.jokers, nil,nil,nil,nil,'j_crv_wip')
   --             new_card:add_to_deck()
   --             G.jokers:emplace(new_card)
   --         end
   --     end,
   --     in_pool = function(self,wawa,wawa2)
   --         return true
   --     end,
   --    }
    
            
